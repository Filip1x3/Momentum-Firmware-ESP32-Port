# Stable Bruce companion for Momentum ESP32 Port

Upstream release: **1.16.1**, commit
`ba519c936c87b89c9c667c15b932d7faca5360d5` from
https://github.com/BruceDevices/firmware/releases/tag/1.16.1 .
This is a modified GPL-3.0 companion, not an unmodified official Bruce binary.
The UI identifies `1.16.1`; its isolated ESP-IDF descriptor identifies
`bruce_mntm_db1` / `1.16.1-db1` for Momentum's compatibility checks.

The port adds the Momentum return menu, confines SD file access to `/bruce`,
redirects Bruce NVS to its separate partition and blocks writes to Momentum's
app/data partitions. It never formats the shared SD. Raw SD mass storage is
disabled because it cannot be restricted to a folder.

Build using the dependencies and framework declared in `platformio.ini`:

```text
pio run -e momentum-dualboot
```

Do not run `pio upload`, erase the chip, flash a factory/merged image or install
this companion alone. The post-build script quarantines the SDK factory image.
Use Momentum's validated segmented Dual Boot bundle, whose app offsets are
`0x10000` for Momentum and `0x600000` for Bruce. Keep all existing NVS partitions.
See the bundle's instructions before installation; a power interruption can
require USB recovery. Keep backups and another U2F recovery method.

`RELEASE-SOURCE.json` in a corresponding-source archive records the upstream
commit and hashes the included source inputs. `.git`, `.pio`, caches and local
device backups are excluded. GPL-3.0 license and upstream notices are retained.

Host-only regressions:

```text
python -m unittest discover -s tests/dualboot -p "test_*.py"
tests\dualboot\build.cmd
```

The optional native Windows tests need Visual Studio Build Tools and do not
touch hardware. They are not a substitute for testing SD, display and return
switching on T-Embed CC1101.
