#include "core/bus_HAL.h"
#include "core/powerSave.h"
#include "core/utils.h"
#include <M5Unified.h>
#include <interface.h>

#define TFT_SCK 20

constexpr uint32_t kBtnBDoublePressWindowMs = 270;
constexpr uint32_t kBtnBLongPressMs = 500;

bool enableNessoGrovePower();

/***************************************************************************************
** Function name: _setup_gpio()
** Location: main.cpp
** Description:   initial setup for the device
***************************************************************************************/
void _setup_gpio() {
    // Piezo buzzer (GPIO11 from schematic)
    bruceConfigPins.buzzer = 11;
    bruceConfigPins.i2c_bus = {(gpio_num_t)5, (gpio_num_t)4};  // sda, scl (Grove)
    bruceConfigPins.sys_i2c = {(gpio_num_t)10, (gpio_num_t)8}; // sda, scl
    bruceConfigPins.rfTx = 5;
    bruceConfigPins.rfRx = 4;
    bruceConfigPins.irTx = 9;
    bruceConfigPins.irRx = 5;
    bruceConfigPins.rotation = 3;
    bruceConfigPins.uart_bus = {(gpio_num_t)4, (gpio_num_t)5};    // rx, tx
    bruceConfigPins.gps_bus = {(gpio_num_t)4, (gpio_num_t)5};     // rx, tx
    bruceConfigPins.badusb_bus = {(gpio_num_t)4, (gpio_num_t)5};  // rx, tx (CH9329, using Grove)
    // Board's default/generic SPI bus (used by drivers without their own bus, e.g. RC522-SPI)
    bruceConfigPins.outer_bus = {(gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7};
    bruceConfigPins.PN532_bus = {(gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7};
    bruceConfigPins.CC1101_bus = {
        (gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7, (gpio_num_t)2, GPIO_NUM_NC
    }; // sck,miso,mosi,cs,gdo0,gdo2
    bruceConfigPins.NRF24_bus = {
        (gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7, (gpio_num_t)2
    }; // sck,miso,mosi,cs(ss),ce
    bruceConfigPins.SDCARD_bus = {(gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7
    }; // sck,miso,mosi,cs
#if !defined(LITE_VERSION)
    bruceConfigPins.W5500_bus = {
        (gpio_num_t)6, (gpio_num_t)4, (gpio_num_t)5, (gpio_num_t)7, (gpio_num_t)2, GPIO_NUM_NC
    }; // sck,miso,mosi,cs,int,rst
    // LoRa shares the TFT SPI bus (sck=TFT_SCK=20, miso=TFT_MISO=22, mosi=TFT_MOSI=21)
    bruceConfigPins.LoRa_bus = {
        (gpio_num_t)20, (gpio_num_t)22, (gpio_num_t)21, (gpio_num_t)23, (gpio_num_t)-1, (gpio_num_t)15
    }; // sck,miso,mosi,cs,rst,dio0
#endif

    M5.begin(); // Need to test if SDCard inits with the new setup
    // ESP32-C6 only has one general-purpose I2C controller (SOC_HP_I2C_NUM == 1), so
    // I2C_NUM_1 doesn't exist in i2c_port_t here and M5.In_I2C is always on Wire/I2C_NUM_0.
    setSysI2CBus(&Wire);
    enableNessoGrovePower();
    bruceConfig.colorInverted = 0;
    M5.BtnA.setDebounceThresh(8);
    M5.BtnB.setDebounceThresh(8);
    M5.BtnB.setHoldThresh(kBtnBLongPressMs);
}

/***************************************************************************************
** Function name: getBattery()
** location: display.cpp
** Description:   Delivers the battery value from 1-100
***************************************************************************************/
int getBattery() {
    int percent = 0;
    percent = M5.Power.getBatteryLevel();
    return (percent < 0) ? 0 : (percent >= 100) ? 100 : percent;
}

/*********************************************************************
** Function: setBrightness
** location: settings.cpp
** set brightness value
**********************************************************************/
void _setBrightness(uint8_t brightval) { M5.Display.setBrightness(brightval); }

/*********************************************************************
** Function: InputHandler
** Handles the variables PrevPress, NextPress, SelPress, AnyKeyPress and EscPress
**********************************************************************/
void InputHandler(void) {
    static unsigned long tm = 0;
    static uint32_t btnBFirstReleaseMs = 0;
    static bool btnBWaitingSecondClick = false;
    static bool btnBLongPressFired = false;
    static bool touchWasPressed = false;
    if (millis() - tm < 200 && !LongPress) return;
    if (!trylockSysI2CBus()) return; // RFID driver mid-transaction - retry next tick
    M5.update();
    unlockSysI2CBus();

    checkPowerSaveTime();

    bool emitNext = false;
    bool emitPrev = false;
    bool emitEsc = false;
    uint32_t now = millis();

    auto t = M5.Touch.getDetail();
    bool touchPressed = t.isPressed() || t.isHolding();
    if (touchPressed && !touchWasPressed) {
        tm = millis();
        touchWasPressed = true;
        if (wakeUpScreen()) return;

        touchPoint.x = t.x;
        touchPoint.y = t.y;
        touchPoint.pressed = true;
        touchHeatMap(touchPoint);
        AnyKeyPress = true;
        return;
    }
    touchWasPressed = touchPressed;

    bool btnAActive = M5.BtnA.isPressed() || M5.BtnA.isHolding();
    bool btnBActive = M5.BtnB.isPressed() || M5.BtnB.isHolding();

    if (M5.BtnB.wasPressed()) btnBLongPressFired = false;

    if (btnBActive && !btnBLongPressFired && M5.BtnB.pressedFor(kBtnBLongPressMs)) {
        btnBLongPressFired = true;
        btnBWaitingSecondClick = false;
        emitEsc = true;
    }

    if (M5.BtnB.wasReleased()) {
        if (btnBLongPressFired) {
            btnBLongPressFired = false;
        } else if (btnBWaitingSecondClick && now - btnBFirstReleaseMs <= kBtnBDoublePressWindowMs) {
            btnBWaitingSecondClick = false;
            emitPrev = true;
        } else {
            btnBWaitingSecondClick = true;
            btnBFirstReleaseMs = now;
        }
    }

    if (btnBWaitingSecondClick && !btnBActive && now - btnBFirstReleaseMs > kBtnBDoublePressWindowMs) {
        btnBWaitingSecondClick = false;
        emitNext = true;
    }

    bool btnAClicked = M5.BtnA.wasClicked();
    AnyKeyPress =
        btnAActive || btnBActive || btnBWaitingSecondClick || btnAClicked || emitNext || emitPrev || emitEsc;
    if (!AnyKeyPress) return;

    if ((btnAActive || btnBActive) && wakeUpScreen()) return;

    if (btnAClicked) SelPress = true;
    if (emitNext) NextPress = true;
    if (emitPrev) PrevPress = true;
    if (emitEsc) EscPress = true;
}

/*********************************************************************
** Function: powerOff
** location: mykeyboard.cpp
** Turns off the device (or try to)
**********************************************************************/
void powerOff() { M5.Power.powerOff(); }
