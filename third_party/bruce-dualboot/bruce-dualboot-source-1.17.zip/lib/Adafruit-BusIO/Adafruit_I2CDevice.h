#ifndef Adafruit_I2CDevice_h
#define Adafruit_I2CDevice_h

#include <Arduino.h>
#include <Wire.h>

///< The class which defines how we will talk to this device over I2C
class Adafruit_I2CDevice {
public:
  Adafruit_I2CDevice(uint8_t addr, TwoWire *theWire = &Wire);
  Adafruit_I2CDevice(uint8_t addr, int sdaPin = -1, int sclPin = -1, TwoWire *theWire = &Wire);
  uint8_t address(void);
  bool begin(bool addr_detect = true);
  void end(void);
  bool detected(void);

  bool read(uint8_t *buffer, size_t len, bool stop = true);
  bool write(const uint8_t *buffer, size_t len, bool stop = true,
             const uint8_t *prefix_buffer = nullptr, size_t prefix_len = 0);
  bool write_then_read(const uint8_t *write_buffer, size_t write_len,
                       uint8_t *read_buffer, size_t read_len,
                       bool stop = false);
  bool setSpeed(uint32_t desiredclk);

  /*!   @brief  Mark the TwoWire as owned by the caller: begin() then won't
   *    (re)initialize it. Use when the bus was already started elsewhere (e.g.
   *    on Wire1, on custom pins, or an adapter that isn't a real controller).
   *    @param  external true if the caller manages the bus */
  void setExternalWire(bool external) { _externalWire = external; }

  /*!   @brief  How many bytes we can read in a transaction
   *    @return The size of the Wire receive/transmit buffer */
  size_t maxBufferSize() { return _maxBufferSize; }

private:
  int _sdaPin;
  int _sclPin;
  uint8_t _addr;
  TwoWire *_wire;
  bool _begun;
  bool _externalWire = false;
  size_t _maxBufferSize;
  bool _read(uint8_t *buffer, size_t len, bool stop);
};

#endif // Adafruit_I2CDevice_h
