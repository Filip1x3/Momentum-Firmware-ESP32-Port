"""Build an application-only companion; never use PIO's stock flash layout."""
from SCons.Script import COMMAND_LINE_TARGETS
Import("env")

if any(target.startswith("upload") or target in ("erase", "program") for target in COMMAND_LINE_TARGETS):
    raise RuntimeError("Standalone upload/erase is disabled. Use the complete Momentum dual-boot bundle.")

# Also redirect explicit default-partition calls from precompiled Arduino/IDF
# libraries, not just Preferences calls in our source files.
for symbol in (
    "nvs_flash_init", "nvs_flash_deinit", "nvs_flash_erase", "nvs_open",
    "nvs_flash_init_partition", "nvs_flash_deinit_partition",
    "nvs_flash_erase_partition", "nvs_open_from_partition",
    "esp_ota_begin", "esp_partition_write", "esp_partition_write_raw", "esp_partition_erase_range",
):
    env.Append(LINKFLAGS=["-Wl,--wrap=" + symbol])

def no_standalone_upload(*args, **kwargs):
    raise RuntimeError("Use the complete Momentum dual-boot bundle; standalone Bruce upload is unsafe.")

env.AddPreAction("upload", no_standalone_upload)
env.AddPreAction("uploadfs", no_standalone_upload)
env.AddPreAction("erase", no_standalone_upload)
