"""Keep the SDK's automatically generated factory image out of installable files."""
from pathlib import Path
Import("env")

build_dir = Path(env.subst("$BUILD_DIR")).resolve()
expected = (Path(env.subst("$PROJECT_DIR")) / ".pio/build/momentum-dualboot").resolve()
if build_dir != expected:
    raise RuntimeError("Use the reviewed .pio/build/momentum-dualboot output directory")

def quarantine_factory_image(*args, **kwargs):
    # This is a generated SDK artifact, never a user file or full-flash backup.
    # Keep it recoverable for inspection but remove its flashable .bin extension.
    source = build_dir / "firmware.factory.bin"
    if source.is_file():
        source.replace(build_dir / "firmware.factory.bin.disabled")
        print("Dual Boot: quarantined SDK factory image; install only the validated segmented bundle.")

# The SDK may create the merge as part of its own binary action. Use the public
# build-alias post hook so cleanup runs after all of those actions, even on a
# subsequent no-change build. The packaging tool also refuses an unsafe merge.
env.AddPostAction("buildprog", quarantine_factory_image)
env.Replace(ESP32_APP_OFFSET="0x600000", FLASH_EXTRA_IMAGES=[])
