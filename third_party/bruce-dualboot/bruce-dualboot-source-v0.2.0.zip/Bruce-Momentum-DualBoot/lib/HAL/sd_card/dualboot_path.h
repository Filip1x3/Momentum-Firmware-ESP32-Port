#pragma once
#include <stddef.h>

// A filesystem convenience boundary, not a sandbox for untrusted native code.
// FAT accepts traversal components; do not let FS APIs leave /bruce.
static inline bool dualboot_path_allowed(const char* path, bool allow_root = true) {
    if(!path || path[0] != '/') return false;
    bool has_component = false;
    const char* part = path + 1;
    for(const char* p = part;; ++p) {
        if(*p == '\\' || *p == ':' || (*p && (unsigned char)*p < 32)) return false;
        if(*p == '/' || !*p) {
            size_t length = p - part;
            // FAT normalises trailing dots/spaces; reject those aliases too.
            if(length && (part[length - 1] == ' ' || part[length - 1] == '.')) return false;
            if((length == 1 && part[0] == '.') ||
               (length == 2 && part[0] == '.' && part[1] == '.')) return false;
            if(length) has_component = true;
            part = p + 1;
            if(!*p) break;
        }
    }
    return allow_root || has_component;
}
