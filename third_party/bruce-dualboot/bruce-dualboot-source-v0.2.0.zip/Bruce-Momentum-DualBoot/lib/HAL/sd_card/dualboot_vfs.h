#pragma once
#include "dualboot_path.h"
#include "vfs_api.h"

class DualBootVFS : public VFSImpl {
public:
    fs::FileImplPtr open(const char* path, const char* mode, bool create) override {
        return dualboot_path_allowed(path) ? VFSImpl::open(path, mode, create) : fs::FileImplPtr();
    }
    bool exists(const char* path) override { return dualboot_path_allowed(path) && VFSImpl::exists(path); }
    bool rename(const char* from, const char* to) override {
        return dualboot_path_allowed(from, false) && dualboot_path_allowed(to, false) && VFSImpl::rename(from, to);
    }
    bool remove(const char* path) override { return dualboot_path_allowed(path, false) && VFSImpl::remove(path); }
    bool mkdir(const char* path) override { return dualboot_path_allowed(path, false) && VFSImpl::mkdir(path); }
    bool rmdir(const char* path) override { return dualboot_path_allowed(path, false) && VFSImpl::rmdir(path); }
};
