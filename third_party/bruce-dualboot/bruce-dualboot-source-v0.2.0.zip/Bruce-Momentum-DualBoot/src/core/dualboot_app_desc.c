/* Override IDF's weak descriptor so Momentum rejects stock/non-isolated Bruce.
 * Use the SDK's normal descriptor layout, revision bounds and MMU page size. */
#ifdef MOMENTUM_DUALBOOT
#include <esp_app_desc.h>
#include <esp_idf_version.h>
#include <sdkconfig.h>
#define DB_STRINGIFY_(x) #x
#define DB_STRINGIFY(x) DB_STRINGIFY_(x)

const __attribute__((used, section(".rodata_desc"))) esp_app_desc_t esp_app_desc = {
    .magic_word = ESP_APP_DESC_MAGIC_WORD,
    .secure_version = 0,
    .version = "1.16-db1",
    .project_name = "bruce_mntm_db1",
    .time = __TIME__,
    .date = __DATE__,
    .idf_ver = "v" DB_STRINGIFY(ESP_IDF_VERSION_MAJOR) "." DB_STRINGIFY(ESP_IDF_VERSION_MINOR)
               "." DB_STRINGIFY(ESP_IDF_VERSION_PATCH),
    .min_efuse_blk_rev_full = CONFIG_ESP_EFUSE_BLOCK_REV_MIN_FULL,
    .max_efuse_blk_rev_full = CONFIG_ESP_EFUSE_BLOCK_REV_MAX_FULL,
    .mmu_page_size = 31 - __builtin_clz(CONFIG_MMU_PAGE_SIZE),
};
#endif
