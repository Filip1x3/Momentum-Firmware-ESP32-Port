/* Arduino/IDF must NEVER initialise/erase Momentum's default "nvs" partition.
 * Linker wrappers include calls from the precompiled WiFi/BLE/Arduino libraries.
 * Keep this C (unmangled symbols) and verify wrappers in the final ELF/map. */
#ifdef MOMENTUM_DUALBOOT
#include <nvs.h>
#include <nvs_flash.h>
#include <esp_partition.h>
#include <esp_ota_ops.h>
#include <string.h>
#include <sdkconfig.h>
#ifdef CONFIG_NVS_ENCRYPTION
#error "Encrypted NVS requires a separately reviewed private key-partition layout"
#endif

static const char* private_partition(const char* label) {
    if(!label || strcmp(label, "nvs") == 0 || strcmp(label, "bruce_nvs") == 0)
        return "bruce_nvs";
    return NULL;
}

static bool layout_ready(void) {
    const esp_partition_t* p = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_NVS, "bruce_nvs");
    return p && p->address == 0xC12000 && p->size == 0x10000;
}

esp_err_t __real_nvs_flash_init_partition(const char*);
esp_err_t __real_nvs_flash_deinit_partition(const char*);
esp_err_t __real_nvs_flash_erase_partition(const char*);
esp_err_t __real_nvs_open_from_partition(const char*, const char*, nvs_open_mode_t, nvs_handle_t*);

esp_err_t __wrap_nvs_flash_init_partition(const char* label) {
    const char* own = private_partition(label);
    if(!own || !layout_ready()) return ESP_ERR_NOT_FOUND;
    esp_err_t result = __real_nvs_flash_init_partition(own);
    // Arduino's fallback selects the FIRST NVS partition with a NULL label
    // (Momentum's). Recover the private store here so that branch is not used.
    // The partition-write guard still blocks the Arduino fallback on failure.
    if(result == ESP_ERR_NVS_NO_FREE_PAGES || result == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        result = __real_nvs_flash_erase_partition(own);
        if(result == ESP_OK) result = __real_nvs_flash_init_partition(own);
    }
    return result;
}
esp_err_t __wrap_nvs_flash_init(void) { return __wrap_nvs_flash_init_partition("bruce_nvs"); }
esp_err_t __wrap_nvs_flash_deinit_partition(const char* label) {
    const char* own = private_partition(label);
    return own && layout_ready() ? __real_nvs_flash_deinit_partition(own) : ESP_ERR_NOT_FOUND;
}
esp_err_t __wrap_nvs_flash_deinit(void) { return __wrap_nvs_flash_deinit_partition("bruce_nvs"); }
esp_err_t __wrap_nvs_flash_erase_partition(const char* label) {
    const char* own = private_partition(label);
    return own && layout_ready() ? __real_nvs_flash_erase_partition(own) : ESP_ERR_NOT_FOUND;
}
esp_err_t __wrap_nvs_flash_erase(void) { return __wrap_nvs_flash_erase_partition("bruce_nvs"); }
esp_err_t __wrap_nvs_open_from_partition(
    const char* label, const char* name, nvs_open_mode_t mode, nvs_handle_t* handle) {
    const char* own = private_partition(label);
    return own && layout_ready() ? __real_nvs_open_from_partition(own, name, mode, handle) : ESP_ERR_NOT_FOUND;
}
esp_err_t __wrap_nvs_open(const char* name, nvs_open_mode_t mode, nvs_handle_t* handle) {
    return __wrap_nvs_open_from_partition("bruce_nvs", name, mode, handle);
}

// Defense in depth: reject ordinary app updates and low-level partition writes
// to either application or Momentum's NVS. Selecting a boot slot still works.
esp_err_t __wrap_esp_ota_begin(const esp_partition_t* p, size_t size, esp_ota_handle_t* handle) {
    (void)p; (void)size; (void)handle;
    return ESP_ERR_NOT_SUPPORTED;
}

static bool writable(const esp_partition_t* p, size_t offset, size_t size) {
    if(!p || offset > p->size || size > p->size - offset) return false;
    return (p->address == 0xC12000 && p->size == 0x10000 && strcmp(p->label, "bruce_nvs") == 0) ||
           (p->address == 0xC22000 && p->size == 0x3DE000 && strcmp(p->label, "spiffs") == 0) ||
           (p->address == 0xBF0000 && p->size == 0x2000 && strcmp(p->label, "otadata") == 0) ||
           (p->address == 0xBF2000 && p->size == 0x20000 && strcmp(p->label, "coredump") == 0);
}

esp_err_t __real_esp_partition_write(const esp_partition_t*, size_t, const void*, size_t);
esp_err_t __real_esp_partition_write_raw(const esp_partition_t*, size_t, const void*, size_t);
esp_err_t __real_esp_partition_erase_range(const esp_partition_t*, size_t, size_t);

esp_err_t __wrap_esp_partition_write(const esp_partition_t* p, size_t offset, const void* data, size_t size) {
    return writable(p, offset, size) ? __real_esp_partition_write(p, offset, data, size) : ESP_ERR_NOT_SUPPORTED;
}
esp_err_t __wrap_esp_partition_write_raw(const esp_partition_t* p, size_t offset, const void* data, size_t size) {
    return writable(p, offset, size) ? __real_esp_partition_write_raw(p, offset, data, size) : ESP_ERR_NOT_SUPPORTED;
}
esp_err_t __wrap_esp_partition_erase_range(const esp_partition_t* p, size_t offset, size_t size) {
    return writable(p, offset, size) ? __real_esp_partition_erase_range(p, offset, size) : ESP_ERR_NOT_SUPPORTED;
}
#endif
